import Holiday_Decorations.HolidayItem;
import Holiday_Decorations.TreeDecorator;
import Holiday_Decorations.TreeType;

public class TreeTester {

	public static void main(String[] args) {
		

	}

}
