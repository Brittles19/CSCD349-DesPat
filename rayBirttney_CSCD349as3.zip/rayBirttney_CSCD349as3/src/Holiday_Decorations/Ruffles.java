package Holiday_Decorations;

public class Ruffles extends TreeDecorator {
	public Ruffles(TreeType tree) {
		super((HolidayItem) tree);
	
	}

	public Ruffles ruffle;
	
	public void addRuffle(Ruffles ruffle)  {
		this.ruffle = ruffle;
		
	}
	
	
	
}
