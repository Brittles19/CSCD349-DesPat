package Holiday_Decorations;

public abstract class TreeDecorator {

	HolidayItem treeDecorationItem; //wrapped item
	
	
	public TreeDecorator(HolidayItem treeDecorations) {
		this.treeDecorationItem = treeDecorations;
		
	}

	public TreeDecorator getTreeDecorationType() {
		return (TreeDecorator) this.treeDecorationItem;
	}

	public void description(TreeDecorator treeDecoratorType) {
		
		System.out.println("You added: " + this.treeDecorationItem + "/n ");
	}
}
	

