package Holiday_Decorations;

public interface HolidayItem {

	public abstract void cost();
	
	public abstract void description();

}

	
	
