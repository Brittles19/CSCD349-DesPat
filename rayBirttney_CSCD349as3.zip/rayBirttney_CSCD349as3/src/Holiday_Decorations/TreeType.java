package Holiday_Decorations;

public class TreeType {
	private TreeType tree;
	
	
	public void getTreeType() 
	{
		System.out.println("You picked: " +  this.tree  + " /n");
	}
	public void description() {
		System.out.println("your " + this.tree + " is ready for decoration " + " /n");
	}
}
