package Holiday_Decorations;

public class Star extends TreeDecorator {
	private Star(HolidayItem star) {
		super(star);
	}
	
	public final static HolidayItem getStar(TreeType tree) {
		return null;
		
		
		
	
}
}
