package Holiday_Decorations;

public class Ornaments extends TreeDecorator {

	
	public Ornaments(HolidayItem treeDecorations) {
		super(treeDecorations);
		
	}

	


	
	
}

	
	
	


